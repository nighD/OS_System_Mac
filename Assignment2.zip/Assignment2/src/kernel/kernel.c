#include "kernel.h"
#define MODE_READ 0
#define MODE_WRITE 1
#define MAX_LEN 32

uint16_t clk_div = 2500 ;
uint8_t slave_address = 0x00;
uint32_t len = 0;
uint8_t *data;
unsigned char wbuf[MAX_LEN];
int i;

void kernel_main()
{
    register unsigned int r;
    wbuf[0] = 0x00;
    wbuf[1] = 0x55;
    unsigned char buff[7];
    char khung[2] = {0x00,0x00};
    slave_address = 0x68;
    len = 7;
    uart_init();
    puts("DS1307 Real Time Clock Data\n");
    puts("---------------------------\n");
    bcm2835_init();

    bcm2835_i2c_begin();
    bcm2835_i2c_setSlaveAddress(slave_address);
    bcm2835_i2c_setClockDivider(clk_div);
    *data = bcm2835_i2c_write(&khung, 2);
    // unsigned char* buttonPressed = 'a';
    // puts(data);
    int condition = 1;
    while(1)
    {   
        while(getc() == 0x00){
            puts("1");
            // puts(itoa((getc()==0x00)));
            // if (getc() == 0x70)
            // {
                // condition = 0;
            // }
        }

        // puts("0");
        // if (getc() == 0x72)
        // {
        //     condition = 1;
        // }
        
        // if(){
        //     putc(getc());
        //     bcm2835_i2c_write(&khung,1);
        //     for (i=0; i<7; i++) buff[i] = 'n';
        //     bcm2835_i2c_read(buff, len);
        //     switch(bcd_to_decimal(buff[3])){
        //         case 1:
        //             puts("Sunday ");
        //             break;
        //         case 2:
        //             puts("Monday ");
        //             break;            
        //         case 3:
        //             puts("Tuesday ");
        //             break;
        //         case 4:
        //             puts("Wednesday ");
        //             break;
        //         case 5:
        //             puts("Thursday ");
        //             break;
        //         case 6:
        //             puts("Friday ");
        //             break;
        //         case 7:
        //             puts("Saturday ");
        //             break;
        //         default:
        //             puts("wrong");

        //     }
        //     puts(itoa(bcd_to_decimal(buff[2])));
        //     puts(":");
        //     puts(itoa(bcd_to_decimal(buff[1])));
        //     puts(":");
        //     puts(itoa(bcd_to_decimal(buff[0])));
        //     puts("  ");
        //     puts(itoa(bcd_to_decimal(buff[4])));
        //     puts("/");
        //     puts(itoa(bcd_to_decimal(buff[5])));
        //     puts("/");
        //     puts(itoa(bcd_to_decimal(buff[6])));
        //     puts("\n");
        //     bcm2835_delay(1000);
        // } 
        // else{
        //     puts("Im do nothing");
        // }
    }
}