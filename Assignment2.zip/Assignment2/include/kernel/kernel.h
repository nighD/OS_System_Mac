#ifndef __KERNEL__
#define __KERNEL__

#include "stdio.h"
#include "stdlib.h"
#include "uart.h"
#include "i2c.h"

#define BUFFERLENGTH 80

#endif